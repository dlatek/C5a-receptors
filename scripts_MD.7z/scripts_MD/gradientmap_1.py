# Reference:
# Wisniewski S, Dragan P, Makal A, Latek D (2022) 
# Helix 8 in chemotactic receptors of the complement system. 
# PLoS Comput Biol 18(7): e1009994. https://doi.org/10.1371/journal.pcbi.1009994

import Bio.PDB
import numpy
import pylab
import os


def line(x,y,range):
    x1=[]
    y1=[]
    for i in numpy.arange(0,range,0.1):
        x+=[range]
        x1+=[range-i]
        y+=[i]
        y1+=[range]
    x+=x1
    y+=y1
    return

def calc_residue_dist(residue_one, residue_two) :
    """Returns the C-alpha distance between two residues"""
    diff_vector  = residue_one["CA"].coord - residue_two["CA"].coord
    if numpy.sqrt(numpy.sum(diff_vector * diff_vector)) < 21:
        return numpy.sqrt(numpy.sum(diff_vector * diff_vector))
    else:
        return 21

def calc_dist_matrix(chain_one, chain_two) :
    """Returns a matrix of C-alpha distances between two chains"""
    answer = numpy.zeros((len(chain_one), len(chain_two)), numpy.float)
    for row, residue_one in enumerate(chain_one) :
        for col, residue_two in enumerate(chain_two) :
            answer[row, col] = calc_residue_dist(residue_one, residue_two)
    return answer


number=len([name for name in os.listdir('.') if os.path.isfile(name) and name.split('.')[-1]=='pdb'])*10
for i in range(0,number,number-10):

    gradientname=str(i)
    pdb='a('+gradientname+')'
    pdb_code = pdb
    pdb_filename = pdb+".pdb"
    
    structure = Bio.PDB.PDBParser().get_structure(pdb_code, pdb_filename)
    model = structure[0]
    
    dist_matrix = calc_dist_matrix(model["P"], model["P"])
    
    pylab.gray()
    pylab.matshow(numpy.transpose(dist_matrix))
    pylab.colorbar()
    x=[]
    y=[]
    line(x,y,39)
    pylab.plot(x,y,label='TM1',linewidth=0.5,color='blue')
    pylab.annotate('TM1',(29,0),color='blue',size=7)
    x=[]
    y=[]
    line(x,y,73)
    pylab.plot(x,y,label='TM2',linewidth=0.5,color='cyan')
    pylab.annotate('TM2',(63,0),color='cyan',size=7)
    x=[]
    y=[]
    line(x,y,121)
    pylab.plot(x,y,label='TM3',linewidth=0.5,color='limegreen')
    pylab.annotate('TM3',(111,0),color='limegreen',size=7)
    x=[]
    y=[]
    line(x,y,164)
    pylab.plot(x,y,label='TM4',linewidth=0.5,color='lime')
    pylab.annotate('TM4',(154,0),color='lime',size=7)
    x=[]
    y=[]
    line(x,y,207)
    pylab.plot(x,y,label='TM5',linewidth=0.5,color='gold')
    pylab.annotate('TM5',(200,0),color='gold',size=7)
    x=[]
    y=[]
    line(x,y,242)
    pylab.plot(x,y,label='TM6',linewidth=0.5,color='orange')
    pylab.annotate('TM6',(232,0),color='orange',size=7)
    x=[]
    y=[]
    line(x,y,280)
    pylab.plot(x,y,label='TM7',linewidth=0.5,color='red')
    pylab.annotate('TM7',(270,0),color='red',size=7)
    

    c1=pylab.Circle((245, 155), 20, color='black', fill=False, clip_on=False)
    c2=pylab.Circle((295, 295), 30, color='black', fill=False, clip_on=False)
    

    fig = pylab.gcf()
    ax = fig.gca()
    
    ax.set_xlim((0, 305))
    ax.set_ylim((305, 0))

    ax.add_patch(c1)
    ax.add_patch(c2)
    

    fig.savefig(gradientname+'.png', dpi=980)


#os.system('convert -delay 15 -loop 0 *.png gradient.gif')

exit()

