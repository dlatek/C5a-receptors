# Reference:
# Wisniewski S, Dragan P, Makal A, Latek D (2022) 
# Helix 8 in chemotactic receptors of the complement system. 
# PLoS Comput Biol 18(7): e1009994. https://doi.org/10.1371/journal.pcbi.1009994

import pandas as pd 
import matplotlib.pyplot as plt
import os 
import csv

distances=[name for name in os.listdir('.') if os.path.isfile(name) and name.split('_')[-1]=='dist.csv']
histograms=[name for name in os.listdir('.') if os.path.isfile(name) and name.split('_')[-1]=='hist.csv']

for dist in distances:
    x = []
    y = []
  
    with open(dist,'r') as csvfile:
        plots = csv.reader(csvfile, delimiter = ',')
      
        for row in plots:
            x+=[float(row[0])*2/10]
            y+=[float(row[1])]
    #plt.figure()
  		
    plt.plot(x, y,label = dist.split('_')[0],linewidth=0.5)
    plt.xlim(xmin=0,xmax=1500)
    plt.xlabel('Time [ns]')
    plt.ylabel('Distance [A]')
    plt.legend()
plt.savefig('graph.png', dpi=980)
