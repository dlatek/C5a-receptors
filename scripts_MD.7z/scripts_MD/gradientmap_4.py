# Reference:
# Wisniewski S, Dragan P, Makal A, Latek D (2022) 
# Helix 8 in chemotactic receptors of the complement system. 
# PLoS Comput Biol 18(7): e1009994. https://doi.org/10.1371/journal.pcbi.1009994

import Bio.PDB
import numpy
import pylab
import os


def line(x,y,range):
    x1=[]
    y1=[]
    for i in numpy.arange(0,range,0.1):
        x+=[range]
        x1+=[range-i]
        y+=[i]
        y1+=[range]
    x+=x1
    y+=y1
    return

def calc_residue_dist(residue_one, residue_two) :
    """Returns the C-alpha distance between two residues"""
    diff_vector  = residue_one["CA"].coord - residue_two["CA"].coord
    if numpy.sqrt(numpy.sum(diff_vector * diff_vector)) < 21:
        return numpy.sqrt(numpy.sum(diff_vector * diff_vector))
    else:
        return 21

def calc_dist_matrix(chain_one, chain_two) :
    """Returns a matrix of C-alpha distances between two chains"""
    answer = numpy.zeros((len(chain_one), len(chain_two)), numpy.float)
    for row, residue_one in enumerate(chain_one) :
        for col, residue_two in enumerate(chain_two) :
            answer[row, col] = calc_residue_dist(residue_one, residue_two)
    return answer


number=len([name for name in os.listdir('.') if os.path.isfile(name) and name.split('.')[-1]=='pdb'])*10
for i in range(0,number,number-10):

    gradientname=str(i)
    pdb='a('+gradientname+')'
    pdb_code = pdb
    pdb_filename = pdb+".pdb"
    
    structure = Bio.PDB.PDBParser().get_structure(pdb_code, pdb_filename)
    model = structure[0]
    
    dist_matrix = calc_dist_matrix(model["P"], model["P"])
    
    pylab.gray()
    pylab.matshow(numpy.transpose(dist_matrix))
    pylab.colorbar()
    
    

    pylab.savefig(gradientname+'.png', dpi=980)




#os.system('convert -delay 15 -loop 0 *.png gradient.gif')

exit()

